Please download LAMBDA 3.0 MATLAB code from this URL:
http://gnss.curtin.edu.au/research/lambda.cfm and put it in this folder.

LAMBDA 3.0 [1] MATLAB code must be obtained exclusively from the website linked above;
redistribution is not allowed.


[1] Verhagen, S. and Li, B. (2012). LAMBDA - Matlab implementation, version 3.0.
Delft University of Technology and Curtin University
